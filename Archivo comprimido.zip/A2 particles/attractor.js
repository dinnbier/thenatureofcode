var Attractor = function(positionX, positionY) {
  this.pos = createVector(positionX, positionY);
  this.mass = 140;
  this.G = 1;
  this.radio=this.mass;
  this.radioInt=150;

  this.calculateAttraction = function(p) {
    // Calculate direction of force
     var force = p5.Vector.sub(this.pos, p.pos);
     // Distance between objects
     var distance = force.mag();
     // Artificial constraint
     distance = constrain(distance, 1, 20);
     // Normalize vector (distance doesn't matter here, we just want this vector for direction)
     force.normalize();
     // Calculate gravitional force magnitude
     var strength=distance/100;
  //  var strength = (this.G * this.mass * p.mass) / (distance * distance);
    force.mult(strength*0.3*distance);


     return force;
  }

  this.calculateDecel = function(p) {
    // Magnitude is coefficient * speed squared
    var speed = p.vel.mag();
    var dragMagnitude = 0.01 * speed * speed;

    // Direction is inverse of velocity
    var dragForce = p.vel.copy();
    dragForce.mult(-1);

    // Scale according to magnitude
    dragForce.setMag(dragMagnitude);
    return dragForce;
  }

  this.calculateAccel = function(p) {
    // Magnitude is coefficient * speed squared
    var speed = p.vel.mag();
    var dragMagnitude = 0.01 * speed;

    // Direction is inverse of velocity
    var dragForce = p.vel.copy();
    dragForce.mult(1);

    // Scale according to magnitude
    dragForce.setMag(dragMagnitude);
    return dragForce;
  }

  this.update = function() {
    this.pos.x=mouseX;
    this.pos.y=mouseY;
  }
  // Method to display
  this.display = function() {
    ellipseMode(CENTER);
    fill(0, 30);
    strokeWeight(0.19);
    stroke(255);
    ellipse(this.pos.x, this.pos.y, 2*this.radio, 2*this.radio);
  }
}
