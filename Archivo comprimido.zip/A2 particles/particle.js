//PARTICLES
//x,y: position
//m=mass of the particles
//a: attractor
function Particle(x, y, m, a){
  this.mass=m;
  this.pos=createVector(x, y);
  this.vel=createVector(0,0);
  this.acc=createVector(0,0);
  this.color= color(random(100, 255), random(10, 56), random(10, 180));
  this.attractor=a;

  this.applyForce=function(force){
      var f=force.copy();
      f.div(this.mass);
      this.acc.add(f);
  };
  //Calculates the distance from the particle to the attractor by using vectors
  this.distanceToAttractor=function(){
    // Calculate direction of force
    var force = p5.Vector.sub(this.pos, this.attractor.pos);
    // Distance between objects
    var distance = force.mag();
    return distance;
  };

  this.update=function(){
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.set(0,0);
    //or this.acc.mult(0)
    this.edges();
  };

  this.display=function(){
    fill(this.color, 2);
    ellipse(this.pos.x, this.pos.y, this.mass*10, this.mass*10);
    stroke(255, 204, 0);
    strokeWeight(2);
  };

  this.edges=function(){

    //control of color of the particle when close to the attractor
    if(this.distanceToAttractor()<=a.radio) {
      this.color=255;
    }else{
      this.color=color(100, 255, 255);
    }

    if(this.pos.y>height){
        this.vel.y*=-1;
        this.pos.y=height;
    }
    if(this.pos.y<0){
        this.vel.y*=-1;
        this.pos.y=0;
    }
    if(this.pos.x>width){
        this.vel.x*=-1;
        this.pos.x=width;
    }

    if(this.pos.x<0){
        this.vel.x*=-1;
        this.pos.x=0;
    }

  }

}
