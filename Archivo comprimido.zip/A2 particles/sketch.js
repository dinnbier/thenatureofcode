
// array
var particles=[];
var numParticles=90;
var attractor;

function setup() {
  var mass, xpos, ypos;
  canvas = createCanvas(windowWidth, windowHeight);
  canvas.position(0,0);
  attractor = new Attractor(mouseX, mouseY);

  for(var i=1; i<=numParticles;i++){
    mass=random(1, 4);
    xpos=random(200, width-200);
    ypos=random(200, height-200);
    particles[i] = new Particle(xpos, ypos, mass, attractor);
    stroke(150);
    if(i>1 && particles[i].distanceToAttractor()<=attractor.radio)
      line(particles[i].pos.x, particles[i].pos.y, particles[i-1].pos.x, particles[i-1].pos.y);
  }




}

function draw() {
  background(51);
  //make mouse dissapear
  if (mouseIsPressed) {
    noCursor();
  }

  var force;
  attractor.update();
  attractor.display();
  for(var i=1; i<=numParticles;i++){

    strokeWeight(0.9);
    if(i>1 && particles[i].distanceToAttractor()<=attractor.radio)
      line(particles[i].pos.x, particles[i].pos.y, particles[i-1].pos.x, particles[i-1].pos.y);
    force=attractor.calculateAttraction(particles[i]);

    //if(particles[i].distanceToAttractor()<=attractor.radioInt)
    force2=attractor.calculateDecel(particles[i]);

    particles[i].applyForce(force);
    particles[i].applyForce(force2);
    particles[i].update();
    particles[i].display();

  }

}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  canvas.position(0, 0);
}
